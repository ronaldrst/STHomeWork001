public class Student {//类首括号

   private int ID;
   private String name;
   private String birDate;
   private boolean gender = true;
   private String sex;


    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirDate() {
        return birDate;
    }

    public void setBirDate(String birDate) {
        this.birDate = birDate;
    }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(boolean gender) {
        if(gender){
            this.sex = "男";
        }
        else{
            this.sex = "女";
        }

    }

    @Override
    public String toString() {
        return "学生信息：" +
                "学号为：" + ID +
                ", 名字为：" + name +
                ", 生日为：" + birDate  +
                ", 性别为：" + sex ;
    }
}//类尾括号

StudentManager.java

import java.util.Scanner;
public class StudentManager {//类首括号

    Scanner scan = new Scanner(System.in);
    Student[] stu = new Student[50];

    int n = 0;

    //        插入
    public void Insert() {//插入函数开始首括号
        Student student = new Student();
        System.out.println("请输入该生的ID");
        int ID = scan.nextInt();
        System.out.println("请输入该生的名称");
        String name = scan.next();
        System.out.println("请输入该生的生日");
        String birthdate = scan.next();
        System.out.println("请输入该生的性别（true为男性，false为女性）");
        boolean gender = scan.nextBoolean();

        student.setID(ID);

        student.setName(name);

        student.setBirDate(birthdate);

        student.setSex(gender);
        stu[n] = student;
        System.out.println(stu[n].toString());
        System.out.println("添加完成！");
        n++;
    }//插入函数结束尾括号

    //        查找
    public void Find() {//查找函数开始首括号
        if (n == 0) {
            System.out.println("抱歉，学生列表为空，请先添加学生信息");
        }
        else {
            System.out.println("请输入想查找学生的ID");
            int aim = scan.nextInt();
            for (int i = 0; i < n; i++) {
                if (stu[i].getID() == aim) {
                    System.out.println("查找到的学生是：" + stu[i].toString());
                }
            }
        }
    }//查找函数结束尾括号

    //        更新数据
    public void Update() {//更新函数开始首括号
        if (n == 0) {
            System.out.println("抱歉，学生列表为空，请先添加学生信息");
        } else {
            System.out.println("请输入想要修改学生的ID");
            int aim = scan.nextInt();
            Student student = new Student();
            for (int i = 0; i < n; i++) {
                if (stu[i].getID() == aim) {
                    stu[i] = student;
                }
            }
            System.out.println("请输入新的ID");
            int ID = scan.nextInt();
            System.out.println("请输入新的名称");
            String name = scan.next();
            System.out.println("请输入新的生日");
            String birthdate = scan.next();
            System.out.println("请输入新的性别（true为男性，false为女性）");
            boolean gender = scan.nextBoolean();
            student.setID(ID);
            student.setName(name);
            student.setBirDate(birthdate);
            student.setSex(gender);
            System.out.println("修改完成！");
        }
    }//更新函数结束尾括号

    //        删除
    public void Delete() {//删除函数开始首括号
        if (n == 0) {
            System.out.println("列表为空！无法删除");
        }
        else {
            System.out.println("请输入想要删除学生的ID");
            int aim = scan.nextInt();
            int delnum = -1;
            for(int j = 0;j<n;j++){
                if (stu[j].getID() == aim) {
                    delnum = j;
                }
            }
            if(delnum==-1){
                System.out.println("抱歉，没有找到指定学生的ID");
            }
            else{
                for (int i = 0; i < n; i++) {
                    if (stu[i].getID() == aim) {
                        delnum = i;
                        for (int j = delnum; j < n; j++) {
                            if (j != n) {
                                stu[j] = stu[j + 1];
                            }

                        }
                        break;
                    }
                }
                n = n - 1;
                System.out.println("删除成功！列表已更新");
            }

        }

    }//删除函数结束尾括号

    //        列出所有数据
    public void List() {//列出函数开始首括号
        if (n == 0) {
            System.out.println("列表为空！请先添加学生");
        }
        else {
            System.out.println("您好！学生信息如下：");
            for (int i = 0; i < n - 1; i++) {
                //第i趟比较
                for (int j = 0; j < n - i - 1; j++) {
                    //开始进行比较，如果arr[j]比arr[j+1]的值大，那就交换位置
                    if (stu[j].getID() > stu[j + 1].getID()) {
                        Student temp = new Student();
                        temp = stu[j];
                        stu[j] = stu[j + 1];
                        stu[j + 1] = temp;
                    }
                }
            }
            for (int q = 0; q < n; q++) {
                System.out.println(stu[q].toString());
            }
        }
    }//列出函数结束尾括号

    public void App() {//APP控制函数开始首括号
        System.out.println(" *          学生管理中心          *");
        System.out.println("*         请选择如下操作：         *");
        System.out.println("***********************************");
        System.out.println("*             1-插入              *");
        System.out.println("*             2-查找              *");
        System.out.println("*             3-删除              *");
        System.out.println("*             4-修改              *");
        System.out.println("*             5-输出              *");
        System.out.println("*             6-退出              *");
        System.out.println("***********************************");

        StudentManager m = new StudentManager();
        while (true) {
            System.out.println("请输入对应的操作码：");
            int number = scan.nextInt();
            if (number == 1 || number == 2 || number == 3 || number == 4 || number == 5)
                switch (number) {
                    case 1:
                        m.Insert();
                        break;
                    case 2:
                        m.Find();
                        break;
                    case 3:
                        m.Delete();
                        break;
                    case 4:
                        m.Update();
                        break;
                    case 5:
                        m.List();
                        break;
                }
            else if (number == 6) {
                System.out.println("退出成功！");
                break;
            } else {
                System.out.println("请输入正确的操作码！");
            }
        }
    }//APP函数结束尾括号

}//类尾括号

