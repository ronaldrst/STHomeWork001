public class Test {//类首括号
    public static void main(String[] args){
        StudentManager m = new StudentManager();
        m.Insert();
        m.Insert();
        m.Insert();
        m.List();
        m.Delete();
        m.List();

        Student a = new Student();
        a.setID(5);
        a.setSex(true);
        a.setName("an");
        a.setBirDate("1222");
        Student b = new Student();
        b = a;
        System.out.println(a.getID()+b.getID());

    }
}//类尾括号
