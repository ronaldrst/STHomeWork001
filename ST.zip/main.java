public class Main {
    public static void main(String[] args){
        StudentManager m = new StudentManager();
        m.App();
    }
}
